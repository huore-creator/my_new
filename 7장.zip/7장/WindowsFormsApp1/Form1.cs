﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            current = DateTime.Now;
            BackColor = Color.SkyBlue;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
        }
        DateTime current;
        public DateTime GetTime() //시간 반환하는 메소드 정의
        {
            return current; // 날짜, 시간을 가진 객체 currnet 반환
        }

        private void Form1_Load(object sender, EventArgs e)
        {
    
        }

    

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(GetTime().ToString(), "현재시간");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            MessageBox.Show("폼이 종료되었습니다");
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("종료하시겠습니까?", "prompt", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) 
                e.Cancel = false;
            else e.Cancel = true;
            }

        private void button3_Click(object sender, EventArgs e)
        {
            Invalidate();
        }

        public void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Random r = new Random();
            Color c = Color.FromArgb(r.Next(0, 255), r.Next(255, 255), r.Next(0, 255));
            g.FillRectangle(new SolidBrush(c),e.ClipRectangle);

        }
    }

}
